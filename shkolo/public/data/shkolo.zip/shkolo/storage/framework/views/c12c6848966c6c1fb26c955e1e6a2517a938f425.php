<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> 
        Links
     <?php $__env->endSlot(); ?>
    
    <div class="body-box " >
        <?php $__currentLoopData = $task2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="main-box " href="<?php echo e($task['URL']); ?>">
                <div class="box1" style="border-color: <?php echo e($task['color']); ?>;" on_click="testPostRoute(<?php echo e($task['ID']); ?>)">
                    <div class="w-100 p-3">
                        <i class="fa fa-plus rounded-circle box2" style="color:<?php echo e($task['color']); ?>; border-color: <?php echo e($task['color']); ?>;"></i>
                <!--<i class="fa fa-plus-circle rounded-circle" style="font-size:48px;color:#ffffff; background-color: #2D5F8B ; border: 3px solid #2D5F8B;"></i>
                <div class="box2 w-100 p-3 rounded-circle">
                <i class="fa fa-cloud"></i>
                <i class="glyphicon glyphicon-cloud"></i>
                <i class="glyphicon glyphicon-remove"></i>
                <span class="icon-name mat-caption">control_point</span>
                <i class="material-icons">cloud</i>
                </div>-->
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php
                foreach ($task2 as $key=>$user) {
                    
                    print_r($key);
                    echo ' -- ';
                    print_r($user['color']);
                    echo '<br />';
                }
                //$count = $task2->count();
                //echo $count;
                
            //print_r($task2);
        ?>
    </div>
    
    
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<script>
    function testPostRoute(UserID) {
		console.log('test1234', UserID);
    }
		
    
</script><?php /**PATH /var/www/testLaminas/laravel/blog2/resources/views/tasks.blade.php ENDPATH**/ ?>